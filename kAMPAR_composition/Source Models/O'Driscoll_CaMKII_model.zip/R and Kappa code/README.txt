These are the R and Kappa files corresponding to the dissertation submission 'Computational Modelling of CaMKII, a Multi-state Biomolecule Involved in Memory'. 

Compatible with KaSim version 4 (in development): https://github.com/Kappa-Dev/KaSim

Github commit hash: fa3b4c7