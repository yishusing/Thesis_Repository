p = 0.9 #Probability of mutant subunit

prob_100 <- rep(0,14)  #Probability of configuration
over_write <- rep(0,14) #Line to insert in Kappa file

z = c("CK(a!1,b!2), CK(a!2,b!3), CK(a!3,b!4), CK(a!4,b!5), CK(a!5,b!6), CK(a!6,b!1)",
      "CK(a!1,b!2), CK(a!2,b!3), CK(a!3,b!4), CK(a!4,b!5), CK(a!5,b!6), CKdead(a!6,b!1)", 
      "CK(a!1,b!2), CK(a!2,b!3), CK(a!3,b!4), CK(a!4,b!5), CKdead(a!5,b!6), CKdead(a!6,b!1)", 
      "CK(a!1,b!2), CK(a!2,b!3), CK(a!3,b!4), CKdead(a!4,b!5), CKdead(a!5,b!6), CKdead(a!6,b!1)", 
      "CK(a!1,b!2), CK(a!2,b!3), CKdead(a!3,b!4), CKdead(a!4,b!5), CKdead(a!5,b!6), CKdead(a!6,b!1)", 
      "CK(a!1,b!2), CKdead(a!2,b!3), CKdead(a!3,b!4), CKdead(a!4,b!5), CKdead(a!5,b!6), CKdead(a!6,b!1)", 
      "CKdead(a!1,b!2), CKdead(a!2,b!3), CKdead(a!3,b!4), CKdead(a!4,b!5), CKdead(a!5,b!6), CKdead(a!6,b!1)", 
      "CKdead(a!1,b!2), CK(a!2,b!3), CKdead(a!3,b!4), CK(a!4,b!5), CKdead(a!5,b!6), CK(a!6,b!1)", 
      "CKdead(a!1,b!2), CKdead(a!2,b!3), CK(a!3,b!4), CKdead(a!4,b!5), CKdead(a!5,b!6), CK(a!6,b!1)",
      "CKdead(a!1,b!2), CKdead(a!2,b!3), CKdead(a!3,b!4), CK(a!4,b!5), CKdead(a!5,b!6), CK(a!6,b!1)",
      "CKdead(a!1,b!2), CKdead(a!2,b!3), CK(a!3,b!4), CKdead(a!4,b!5), CK(a!5,b!6), CK(a!6,b!1)",
      "CK(a!1,b!2), CK(a!2,b!3), CKdead(a!3,b!4), CK(a!4,b!5), CK(a!5,b!6), CKdead(a!6,b!1)",
      "CK(a!1,b!2), CKdead(a!2,b!3), CK(a!3,b!4), CKdead(a!4,b!5), CK(a!5,b!6), CK(a!6,b!1)",
      "CKdead(a!1,b!2), CKdead(a!2,b!3), CK(a!3,b!4), CK(a!4,b!5), CKdead(a!5,b!6), CK(a!6,b!1)") 

probabilities = c((1-p)^6, p*((1-p)^5)*6,(p^2)*((1-p)^4)*6,(p^3)*((1-p)^3)*6,(p^4)*((1-p)^2)*6,(p^5)*(1-p)*6,p^6,(p^3)*((1-p)^3)*2,(p^4)*((1-p)^2)*3,(p^4)*((1-p)^2)*6, (p^3)*((1-p)^3)*6,(p^2)*((1-p)^4)*3,(p^2)*((1-p)^4)*6,(p^3)*((1-p)^3)*6)    


for(i in 1:length(z)){
  prob_100[i] = toString(probabilities[i]*100)   #Convert no. of hexamers with this configuration to a string
  over_write[i] = paste("%init:",prob_100[i],z[i],sep=" ") #Concatenate to form Kappa code
  
}

mutant = readLines("mutanttrial.ka", warn=FALSE) #Original Kappa file
mutant[9:22] = over_write
writeLines(mutant,"mutantnew.ka") #New Kappa file with mutant proportions

ntrials <- 10 #Number of trials/simulations to run
res <- array(0, dim=c(201,5,ntrials)) #Array to store data from each simulation
timeofphos <- rep(0, ntrials)
hexphos <- rep(0,ntrials)
mean_subunits <- rep(0,ntrials)
max_hex <- rep(0,ntrials)
max_subunits <- rep(0,ntrials)
time_dephos <- rep(0,ntrials)

colnames(res) <- c("Time","FreeCaM","PhosSubunits","PhosHex","FreePP") #Name columns corresponding to observables

#Add dat to array each iteration/simulation
for(i in 1:ntrials){
  
  dat <- run.kasim("mutantfun.ka", l=0.2, p=0.001) #Run the KaSim simulation
  res[,,i] <- as.matrix(dat)
  #x <- data.frame(res[,1,1],res[,4,1])  #Number of phosphorylated hexamers at each time point (to measure subunits change 4 to 3) 
  #write.table(x, file="mydata1.csv",sep=",",row.names=FALSE,col.names=FALSE) #Add this data to a CSV file
  
  
  if(length(res[res[,3,i] > 0])){
    phos_sub <- which(res[,3,i] >= 1, arr.in=TRUE)
    timeofphos[i] <- res[phos_sub[1]] #time for first subunit phosphorylation
  }
  if(length(res[res[,4,i] > 0])){
    phos_hexamer <- which(res[,4,i] >= 1, arr.in=TRUE)
    hexphos[i] <- res[phos_hexamer[1]] #time for first hexamer phosphorylation
  }
  
  if(length(res[res[-seq_len(15),4,i] == 0])) {
    dephos_hex <- which(res[-seq_len(15),4,i] == 0, arr.in=TRUE)
    time_dephos[i] <- res[dephos_hex[1]+15]
  }
  
  mean_subunits[i] <- mean(res[-seq_len(116),3,i]) #mean no. subunits phos at equilibrium (t>0.15s)
  max_subunits[i] <- max(res[-seq_len(116),3,i])
  max_hex[i] <- max(res[,4,i]) #Max no. of hexamers which are autophosphorylated
}

mean_obs = apply(res,2,mean)
mean_matrix = apply(res,c(1,2),mean) #Average simulation from the trials

max_max = max(max_subunits) #Overall maximum number phos subunits
mean_sub = mean(mean_subunits) #Overall mean phosporylated subunits at equilibrium
mean_dephos_time = mean(time_dephos) 








